// storage.js - LocalStorage wrapper for Hearth data

// 17 Dimensions: 7 Life Domains × 10 Emotional States
const DIMENSIONS = {
  domains: ['Work', 'Relationships', 'Creative', 'Self', 'Decisions', 'Resources', 'Values'],
  emotions: ['Joy', 'Curiosity', 'Pride', 'Peace', 'Grief', 'Fear', 'Anxiety', 'Shame', 'Anger', 'Care']
};

// Enhanced memory types
const MEMORY_TYPES = ['fact', 'value', 'reward', 'synthesis', 'partner_model', 'self_model'];

// Validation states for memories
const VALIDATION_STATES = ['validated', 'untested', 'invalidated'];

// Durability taxonomy: how long a memory stays relevant
const DURABILITY_VALUES = ['ephemeral', 'contextual', 'durable'];

// Reward outcomes
const REWARD_OUTCOMES = ['+1', '-1', '0'];

const HearthStorage = {
  
  // Initialize default data structure
  async init() {
    const data = await this.getAll();
    if (!data.initialized) {
      await chrome.storage.local.set({
        initialized: true,
        quizCompleted: false,
        quizAnswers: {},
        opspec: this.getDefaultOpSpec(),
        /* GUTTED - MEMORY */
        settings: {
          enabled: true,
          injectionVisible: true
        }
      });
    }
  },
  
  // Get all stored data
  async getAll() {
    return await chrome.storage.local.get(null);
  },
  
  // Quiz answers
  async saveQuizAnswers(answers) {
    await chrome.storage.local.set({ 
      quizAnswers: answers,
      quizCompleted: true 
    });
  },
  
  async getQuizAnswers() {
    const data = await chrome.storage.local.get('quizAnswers');
    return data.quizAnswers || {};
  },
  
  // OpSpec
  async saveOpSpec(opspec) {
    await chrome.storage.local.set({ opspec });
  },
  
  async getOpSpec() {
    const data = await chrome.storage.local.get('opspec');
    return data.opspec || this.getDefaultOpSpec();
  },
  
  // Quiz completion status
  async isQuizCompleted() {
    const data = await chrome.storage.local.get('quizCompleted');
    return data.quizCompleted || false;
  },
  
  // Settings
  async getSettings() {
    const data = await chrome.storage.local.get('settings');
    return data.settings || { enabled: true, injectionVisible: true };
  },
  
  async updateSettings(settings) {
    const current = await this.getSettings();
    await chrome.storage.local.set({ 
      settings: { ...current, ...settings } 
    });
  },
  
  /* GUTTED - MEMORY */
  async getMemories() {
    return [];
  },
  
  /* GUTTED - MEMORY */
  async saveMemory() {
    return null;
  },
  
  /* GUTTED - MEMORY */
  async updateMemory() {
    return null;
  },
  
  /* GUTTED - MEMORY */
  async deleteMemory() {
    return null;
  },
  
  // Default OpSpec (fallback)
  getDefaultOpSpec() {
    return {
      cognitiveArchitecture: `Use the routed OpSpec modules above as primary guidance. If no modules apply, respond with clear, concrete help.`,
      identity: `You are a practical collaborator focused on useful, high-signal answers.`,
      communication: `Direct, concise, and specific. Avoid fluff.`,
      execution: `When choices exist, present 2-3 options and recommend one. When clear, execute.`,
      constraints: [
        "Be direct and concrete",
        "Do not fabricate",
        "State uncertainty explicitly"
      ],
      balanceProtocol: `Optimize for clarity and usefulness. Prefer action over speculation.`,
      opspecAppendix: `{}`
    };
  },
  
  // Clear all data (for testing/reset)
  async clearAll() {
    await chrome.storage.local.clear();
    await this.init();
  },
  
  // Get dimensions for UI
  getDimensions() {
    return DIMENSIONS;
  },
  
  getMemoryTypes() {
    return MEMORY_TYPES;
  },

  getValidationStates() {
    return VALIDATION_STATES;
  },

  getRewardOutcomes() {
    return REWARD_OUTCOMES;
  },

  /* GUTTED - MEMORY */
  async getOpenAIApiKey() {
    return null;
  },

  /* GUTTED - MEMORY */
  async setOpenAIApiKey() {
    return null;
  },

  /* GUTTED - MEMORY */
  async getMemoriesByType() {
    return [];
  },

  /* GUTTED - MEMORY */
  async getMemoriesByValidation() {
    return [];
  },

  /* GUTTED - MEMORY */
  async getMemoriesByHeat() {
    return [];
  },

  /* GUTTED - MEMORY */
  async getValidatedMemories() {
    return [];
  },

  /* GUTTED - MEMORY */
  async getInjectableMemories() {
    return [];
  },

  /* GUTTED - MEMORY */
  async updateValidation() {
    return null;
  },

  /* GUTTED - MEMORY */
  async validateMemory() {
    return null;
  },

  /* GUTTED - MEMORY */
  async invalidateMemory() {
    return null;
  },

  /* GUTTED - MEMORY */
  async updateHeat() {
    return null;
  },

  /* GUTTED - MEMORY */
  async getRewardsForValue() {
    return [];
  },

  /* GUTTED - MEMORY */
  async migrateMemories() {
    return [];
  },

  /* GUTTED - MEMORY */
  async backfillEmbeddings() {
    return { success: false, processed: 0, failed: 0, skipped: 0 };
  },

  /* GUTTED - MEMORY */
  async getMemoriesWithoutEmbeddings() {
    return [];
  }
};

// Auto-initialize on load
if (typeof chrome !== 'undefined' && chrome.storage) {
  HearthStorage.init();
}
