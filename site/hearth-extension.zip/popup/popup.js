// popup.js - Quiz logic and UI controller

let currentQuestionIndex = 0;
let answers = {};

// Initialize on load
document.addEventListener('DOMContentLoaded', async () => {
  const quizCompleted = await HearthStorage.isQuizCompleted();

  if (quizCompleted) {
    showDashboard();
  } else {
    showScreen('welcome-screen');
  }

  setupEventListeners();
});

function setupEventListeners() {
  // Welcome screen
  document.getElementById('start-quiz-btn').addEventListener('click', startQuiz);
  document.getElementById('skip-quiz-btn').addEventListener('click', skipQuiz);

  // Quiz navigation
  document.getElementById('back-btn').addEventListener('click', previousQuestion);
  document.getElementById('next-btn').addEventListener('click', nextQuestion);

  // Result screen
  document.getElementById('toggle-opspec-btn').addEventListener('click', toggleOpSpec);
  document.getElementById('start-using-btn').addEventListener('click', finishQuiz);
  document.getElementById('retake-quiz-btn').addEventListener('click', retakeQuiz);
  document.getElementById('edit-opspec-btn').addEventListener('click', editOpSpec);

  // Dashboard
  document.getElementById('retake-quiz-dashboard-btn').addEventListener('click', retakeQuiz);
  document.getElementById('enable-injection-toggle').addEventListener('change', toggleInjection);
  document.getElementById('visible-injection-toggle').addEventListener('change', toggleVisibility);
  document.getElementById('view-edit-opspec-btn').addEventListener('click', viewEditOpSpec);

  // Extract Now buttons — flush pending memories on active tab
  const flushHandler = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'HEARTH_FLUSH_MEMORIES' });
      }
    });
  };
  const extractNowBtn = document.getElementById('extract-now-btn');
  const extractNowHeaderBtn = document.getElementById('extract-now-header-btn');
  if (extractNowBtn) extractNowBtn.addEventListener('click', flushHandler);
  if (extractNowHeaderBtn) extractNowHeaderBtn.addEventListener('click', flushHandler);

  /* KEEP? - OPSPEC REPURPOSE */
}

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.add('hidden');
  });
  document.getElementById(screenId).classList.remove('hidden');
}

function startQuiz() {
  currentQuestionIndex = 0;
  answers = {};
  showScreen('quiz-screen');
  renderQuestion();
}

function skipQuiz() {
  // Use default OpSpec
  showDashboard();
}

function renderQuestion() {
  const question = QUIZ_QUESTIONS[currentQuestionIndex];
  const totalQuestions = QUIZ_QUESTIONS.length;

  // Update progress
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;
  document.getElementById('progress-fill').style.width = `${progress}%`;
  document.getElementById('current-question').textContent = currentQuestionIndex + 1;
  document.getElementById('total-questions').textContent = totalQuestions;

  // Update section label
  const sectionLabels = {
    'identity': 'Section 1: Identity',
    'communication': 'Section 2: Communication',
    'execution': 'Section 3: Execution',
    'preferences': 'Section 4: Preferences',
    'dealbreakers': 'Section 4: Dealbreakers'
  };
  document.getElementById('section-label').textContent = sectionLabels[question.section] || '';

  // Update question text
  document.getElementById('question-text').textContent = question.text;
  document.getElementById('question-instruction').textContent = question.instruction || '';

  // Render answers based on type
  const container = document.getElementById('answers-container');
  container.innerHTML = '';

  if (question.type === 'single') {
    renderSingleChoice(question, container);
  } else if (question.type === 'multi') {
    renderMultiChoice(question, container);
  } else if (question.type === 'pairs') {
    renderPairs(question, container);
  }

  // Update navigation buttons
  document.getElementById('back-btn').disabled = currentQuestionIndex === 0;
  updateNextButton();
}

function renderSingleChoice(question, container) {
  question.answers.forEach(answer => {
    const option = document.createElement('div');
    option.className = 'answer-option';
    option.dataset.questionId = question.id;
    option.dataset.answerId = answer.id;

    if (answers[question.id] === answer.id) {
      option.classList.add('selected');
    }

    option.innerHTML = `
      <span class="emoji">${answer.emoji}</span>
      <span class="text">${answer.text}</span>
    `;

    option.addEventListener('click', () => {
      answers[question.id] = answer.id;
      document.querySelectorAll(`[data-question-id="${question.id}"]`).forEach(el => {
        el.classList.remove('selected');
      });
      option.classList.add('selected');
      updateNextButton();
    });

    container.appendChild(option);
  });
}

function renderMultiChoice(question, container) {
  question.answers.forEach(answer => {
    const option = document.createElement('div');
    option.className = 'answer-option';
    option.dataset.questionId = question.id;
    option.dataset.answerId = answer.id;

    const currentAnswers = answers[question.id] || [];
    if (currentAnswers.includes(answer.id)) {
      option.classList.add('selected');
    }

    option.innerHTML = `
      <span class="emoji">${answer.emoji}</span>
      <span class="text">${answer.text}</span>
    `;

    option.addEventListener('click', () => {
      if (!answers[question.id]) {
        answers[question.id] = [];
      }

      const index = answers[question.id].indexOf(answer.id);
      if (index > -1) {
        answers[question.id].splice(index, 1);
        option.classList.remove('selected');
      } else {
        // Check max selections
        if (question.maxSelections && answers[question.id].length >= question.maxSelections) {
          alert(`You can only select ${question.maxSelections} options for this question.`);
          return;
        }
        answers[question.id].push(answer.id);
        option.classList.add('selected');
      }

      updateNextButton();
    });

    container.appendChild(option);
  });
}

function renderPairs(question, container) {
  if (!answers[question.id]) {
    answers[question.id] = {};
  }

  question.pairs.forEach(pair => {
    const row = document.createElement('div');
    row.className = 'pair-row';

    const leftOption = createPairOption(question.id, pair.id, 'A', pair.left);
    const rightOption = createPairOption(question.id, pair.id, 'B', pair.right);

    row.appendChild(leftOption);
    row.appendChild(rightOption);
    container.appendChild(row);
  });
}

function createPairOption(questionId, pairId, side, data) {
  const option = document.createElement('div');
  option.className = 'pair-option';
  option.dataset.pairId = pairId;
  option.dataset.side = side;

  if (answers[questionId][pairId] === side) {
    option.classList.add('selected');
  }

  option.innerHTML = `
    <span class="emoji">${data.emoji}</span>
    <span class="text">${data.text}</span>
  `;

  option.addEventListener('click', () => {
    answers[questionId][pairId] = side;
    document.querySelectorAll(`[data-pair-id="${pairId}"]`).forEach(el => {
      el.classList.remove('selected');
    });
    option.classList.add('selected');
    updateNextButton();
  });

  return option;
}

function updateNextButton() {
  const question = QUIZ_QUESTIONS[currentQuestionIndex];
  const nextBtn = document.getElementById('next-btn');

  let isAnswered = false;

  if (question.type === 'single') {
    isAnswered = !!answers[question.id];
  } else if (question.type === 'multi') {
    isAnswered = answers[question.id] && answers[question.id].length > 0;
  } else if (question.type === 'pairs') {
    isAnswered = answers[question.id] &&
      Object.keys(answers[question.id]).length === question.pairs.length;
  }

  nextBtn.disabled = !isAnswered;
}

function previousQuestion() {
  if (currentQuestionIndex > 0) {
    currentQuestionIndex--;
    renderQuestion();
  }
}

function nextQuestion() {
  if (currentQuestionIndex < QUIZ_QUESTIONS.length - 1) {
    currentQuestionIndex++;
    renderQuestion();
  } else {
    // Quiz complete!
    completeQuiz();
  }
}

async function completeQuiz() {
  // Generate OpSpec from answers
  const opspec = OpSpecGenerator.generate(answers);
  const profile = OpSpecGenerator.buildProfile(answers);
  const summary = OpSpecGenerator.generateSummary(opspec, profile);

  // Save to storage
  await HearthStorage.saveQuizAnswers(answers);
  await HearthStorage.saveOpSpec(opspec);

  // Show result screen
  showResult(opspec, summary);
}

function showResult(opspec, summary) {
  // Set archetype
  document.getElementById('archetype-title').textContent = summary.archetype;
  document.getElementById('archetype-subtitle').textContent = "Here's how I'll work with you:";

  // Set highlights
  const highlightsList = document.getElementById('highlights-list');
  highlightsList.innerHTML = '';
  summary.highlights.forEach(highlight => {
    const item = document.createElement('div');
    item.className = 'highlight-item';
    item.innerHTML = `
      <span class="icon">${highlight.icon}</span>
      <span class="text">${highlight.text}</span>
    `;
    highlightsList.appendChild(item);
  });

  // Set full OpSpec
  document.getElementById('opspec-identity').textContent = opspec.identity;
  document.getElementById('opspec-communication').textContent = opspec.communication;
  document.getElementById('opspec-execution').textContent = opspec.execution;
  document.getElementById('opspec-balance').textContent = opspec.balanceProtocol || opspec.balanceCheck || '';

  const constraintsList = document.getElementById('opspec-constraints');
  constraintsList.innerHTML = '';
  opspec.constraints.forEach(constraint => {
    const li = document.createElement('li');
    li.textContent = constraint;
    constraintsList.appendChild(li);
  });

  showScreen('result-screen');
}

function toggleOpSpec() {
  const fullOpSpec = document.getElementById('opspec-full');
  const toggleBtn = document.getElementById('toggle-opspec-btn');

  if (fullOpSpec.classList.contains('hidden')) {
    fullOpSpec.classList.remove('hidden');
    toggleBtn.textContent = 'Hide Full Operating Specification ▲';
  } else {
    fullOpSpec.classList.add('hidden');
    toggleBtn.textContent = 'See Full Operating Specification ▼';
  }
}

async function finishQuiz() {
  await HearthStorage.saveQuizAnswers(answers);
  showDashboard();
}

async function retakeQuiz() {
  const confirmed = confirm('This will reset your quiz answers and generate a new Operating Specification. Continue?');
  if (confirmed) {
    startQuiz();
  }
}

function editOpSpec() {
  // TODO: Phase 2 - Add OpSpec editor
  alert('OpSpec editor coming soon! For now, retake the quiz to generate a new one.');
}

async function viewEditOpSpec() {
  const opspec = await HearthStorage.getOpSpec();
  window.__hearthOpspecAppendix = opspec.opspecAppendix || '';

  // Create modal dynamically
  const existingModal = document.getElementById('opspec-modal');
  if (existingModal) {
    existingModal.remove();
  }

  const modal = document.createElement('div');
  modal.id = 'opspec-modal';
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content" style="max-height: 90vh; overflow-y: auto;">
      <div class="modal-header">
        <h3>Operating Specification</h3>
        <button class="close-btn" onclick="document.getElementById('opspec-modal').classList.add('hidden')">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="opspec-cognitive-edit">Cognitive Architecture (The Internal Council)</label>
          <textarea id="opspec-cognitive-edit" rows="6" style="width: 100%;">${opspec.cognitiveArchitecture || ''}</textarea>
        </div>
        <div class="form-group">
          <label for="opspec-identity-edit">Identity</label>
          <textarea id="opspec-identity-edit" rows="4" style="width: 100%;">${opspec.identity || ''}</textarea>
        </div>
        <div class="form-group">
          <label for="opspec-communication-edit">Communication Style</label>
          <textarea id="opspec-communication-edit" rows="2" style="width: 100%;">${opspec.communication || ''}</textarea>
        </div>
        <div class="form-group">
          <label for="opspec-execution-edit">Execution</label>
          <textarea id="opspec-execution-edit" rows="3" style="width: 100%;">${opspec.execution || ''}</textarea>
        </div>
        <div class="form-group">
          <label for="opspec-constraints-edit">Constraints (one per line)</label>
          <textarea id="opspec-constraints-edit" rows="8" style="width: 100%;">${(opspec.constraints || []).join('\n')}</textarea>
        </div>
        <div class="form-group">
          <label for="opspec-balance-protocol-edit">Balance Protocol</label>
          <textarea id="opspec-balance-protocol-edit" rows="6" style="width: 100%;">${opspec.balanceProtocol || ''}</textarea>

          <textarea id="opspec-appendix-edit" rows="6" style="width: 100%; display: none;">${opspec.opspecAppendix || ''}</textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" onclick="document.getElementById('opspec-modal').classList.add('hidden')">Cancel</button>
        <button class="btn-primary" onclick="saveOpSpecFromModal()">Save Changes</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
}

async function saveOpSpecFromModal() {
  const opspec = {
    cognitiveArchitecture: document.getElementById('opspec-cognitive-edit').value.trim(),
    identity: document.getElementById('opspec-identity-edit').value.trim(),
    communication: document.getElementById('opspec-communication-edit').value.trim(),
    execution: document.getElementById('opspec-execution-edit').value.trim(),
    constraints: document.getElementById('opspec-constraints-edit').value.trim().split('\n').filter(c => c.trim()),
    balanceProtocol: document.getElementById('opspec-balance-protocol-edit').value.trim(),
    opspecAppendix: (document.getElementById('opspec-appendix-edit')?.value || window.__hearthOpspecAppendix || '').trim()
  };

  try {
    await HearthStorage.saveOpSpec(opspec);
    document.getElementById('opspec-modal').classList.add('hidden');
    showDashboard();
  } catch (error) {
    alert('Error saving OpSpec: ' + error.message);
  }
}

async function showDashboard() {
  const opspec = await HearthStorage.getOpSpec();
  const settings = await HearthStorage.getSettings();

  // Show summary
  const summary = document.getElementById('dashboard-opspec-summary');
  const identity = opspec.identity || '';
  summary.textContent = identity.length > 120 ? `${identity.substring(0, 120)}...` : identity;

  // Set toggles
  document.getElementById('enable-injection-toggle').checked = settings.enabled;
  document.getElementById('visible-injection-toggle').checked = settings.injectionVisible;

  // Update status indicator
  const statusDot = document.querySelector('.status-dot');
  const statusText = document.querySelector('.status-indicator span:last-child');
  if (settings.enabled) {
    statusDot.classList.add('active');
    statusText.textContent = 'Active';
  } else {
    statusDot.classList.remove('active');
    statusText.textContent = 'Inactive';
  }

  /* KEEP? - OPSPEC REPURPOSE */

  showScreen('dashboard-screen');
}

async function toggleInjection(e) {
  await HearthStorage.updateSettings({ enabled: e.target.checked });
  showDashboard();
}

async function toggleVisibility(e) {
  await HearthStorage.updateSettings({ injectionVisible: e.target.checked });
}

// ============================================
// V2 FEATURES: OpenAI Key, Embeddings, Coverage
// ============================================

async function initV2Features() {
  // Load saved OpenAI key status
  const data = await chrome.storage.local.get(['openaiKey']);
  const statusEl = document.getElementById('openai-key-status');
  if (statusEl) {
    if (data.openaiKey) {
      statusEl.textContent = '✓ Key saved (hidden for security)';
      statusEl.style.color = '#28a745';
    } else {
      statusEl.textContent = 'No key set - semantic search disabled';
      statusEl.style.color = '#666';
    }
  }

  // Setup V2 event listeners
  setupV2EventListeners();
}

function setupV2EventListeners() {
  // Save OpenAI Key
  const saveKeyBtn = document.getElementById('save-openai-key-btn');
  if (saveKeyBtn && !saveKeyBtn.hasAttribute('data-v2-bound')) {
    saveKeyBtn.setAttribute('data-v2-bound', 'true');
    saveKeyBtn.addEventListener('click', async () => {
      const keyInput = document.getElementById('openai-key-input');
      const statusEl = document.getElementById('openai-key-status');
      const key = keyInput.value.trim();

      if (!key) {
        statusEl.textContent = 'Please enter a key';
        statusEl.style.color = '#dc3545';
        return;
      }

      if (!key.startsWith('sk-')) {
        statusEl.textContent = 'Invalid key format (should start with sk-)';
        statusEl.style.color = '#dc3545';
        return;
      }

      await chrome.storage.local.set({ openaiKey: key });
      keyInput.value = '';
      statusEl.textContent = '✓ Key saved! Reload page to enable semantic search.';
      statusEl.style.color = '#28a745';
    });
  }

  // Backfill Embeddings
  const backfillBtn = document.getElementById('backfill-embeddings-btn');
  if (backfillBtn && !backfillBtn.hasAttribute('data-v2-bound')) {
    backfillBtn.setAttribute('data-v2-bound', 'true');
    backfillBtn.addEventListener('click', async () => {
      const statusEl = document.getElementById('backfill-status');
      statusEl.textContent = 'Starting backfill...';
      statusEl.style.color = '#666';

      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'HEARTH_BACKFILL_EMBEDDINGS' });

        if (response?.success) {
          statusEl.textContent = `✓ Backfilled ${response.updated} memories`;
          statusEl.style.color = '#28a745';
        } else {
          statusEl.textContent = 'Backfill failed: ' + (response?.error || 'Unknown error');
          statusEl.style.color = '#dc3545';
        }
      } catch (error) {
        statusEl.textContent = 'Error: ' + error.message;
        statusEl.style.color = '#dc3545';
      }
    });
  }

  // Show Memory Coverage (17 dimensions)
  const coverageBtn = document.getElementById('show-coverage-btn');
  if (coverageBtn && !coverageBtn.hasAttribute('data-v2-bound')) {
    coverageBtn.setAttribute('data-v2-bound', 'true');
    coverageBtn.addEventListener('click', async () => {
      const displayEl = document.getElementById('coverage-display');
      displayEl.classList.remove('hidden');
      displayEl.innerHTML = 'Loading...';

      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'HEARTH_GET_DIMENSIONAL_COVERAGE' });

        if (response?.success) {
          const { coverage, gaps } = response;

          let html = '<strong>Memory Coverage (7 Life Domains × 10 Emotions)</strong><br><br>';

          if (coverage.length > 0) {
            html += '<div style="margin-bottom: 10px;"><strong>Covered:</strong></div>';
            html += '<ul style="margin: 0; padding-left: 20px;">';
            for (const c of coverage.slice(0, 10)) {
              html += `<li>${c.life_domain} × ${c.emotional_state}: ${c.memory_count} memories</li>`;
            }
            if (coverage.length > 10) {
              html += `<li>...and ${coverage.length - 10} more</li>`;
            }
            html += '</ul>';
          }

          if (gaps.length > 0) {
            html += '<div style="margin-top: 10px;"><strong>Gaps (no memories):</strong></div>';
            html += '<ul style="margin: 0; padding-left: 20px; color: #999;">';
            for (const g of gaps.slice(0, 5)) {
              html += `<li>${g.life_domain} × ${g.emotional_state}</li>`;
            }
            if (gaps.length > 5) {
              html += `<li>...and ${gaps.length - 5} more gaps</li>`;
            }
            html += '</ul>';
          }

          displayEl.innerHTML = html;
        } else {
          displayEl.innerHTML = 'Error: ' + (response?.error || 'Could not load coverage');
        }
      } catch (error) {
        displayEl.innerHTML = 'Error: ' + error.message;
      }
    });
  }

  // Memory Consolidation
  const consolidateBtn = document.getElementById('consolidate-memories-btn');
  if (consolidateBtn && !consolidateBtn.hasAttribute('data-v2-bound')) {
    consolidateBtn.setAttribute('data-v2-bound', 'true');
    consolidateBtn.addEventListener('click', async () => {
      const statusEl = document.getElementById('consolidation-status');
      statusEl.textContent = 'Initializing consolidation...';
      statusEl.style.color = '#666';

      try {
        const data = await chrome.storage.local.get(['openaiKey']);
        if (!data.openaiKey) {
          statusEl.textContent = 'Error: No OpenAI Key saved.';
          statusEl.style.color = '#dc3545';
          return;
        }

        if (!window.HearthSupabase || !window.HearthMemoryConsolidator) {
          statusEl.textContent = 'Error: Modules not loaded. Refresh popup.';
          statusEl.style.color = '#dc3545';
          return;
        }

        const consolidator = new window.HearthMemoryConsolidator(
          window.HearthSupabase,
          data.openaiKey
        );

        statusEl.textContent = 'Scanning recent memories for conflicts...';

        const count = await consolidator.scanAndConsolidate(10, (msg) => {
          statusEl.textContent = msg;
        });

        statusEl.textContent = `✓ Scan complete. Resolved ${count} conflicts.`;
        statusEl.style.color = '#28a745';

      } catch (error) {
        console.error('Consolidation failed', error);
        statusEl.textContent = 'Error: ' + error.message;
        statusEl.style.color = '#dc3545';
      }
    });
  }
}

// Wrap showDashboard to include V2 initialization
const _originalShowDashboard = showDashboard;
showDashboard = async function () {
  await _originalShowDashboard();
  await initV2Features();
};
